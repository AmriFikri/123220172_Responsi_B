-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2024 at 05:04 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym`
--

-- --------------------------------------------------------

--
-- Table structure for table `datagym`
--

CREATE TABLE `datagym` (
  `Nama Penyewa` varchar(100) NOT NULL,
  `Nama Alat` varchar(100) NOT NULL,
  `Nomor Telepon` int(50) NOT NULL,
  `Waktu Sewa` int(10) NOT NULL,
  `Biaya Sewa` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datagym`
--

INSERT INTO `datagym` (`Nama Penyewa`, `Nama Alat`, `Nomor Telepon`, `Waktu Sewa`, `Biaya Sewa`) VALUES
('Abdul', 'Dumbell 5KG', 812348211, 2, 0),
('Malik', 'Barbell 15 KG', 867476133, 2, 0),
('Rusdi', 'Treadmill', 888213342, 5, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
